package com.example.mainscreen;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Objects;

public class Game9result extends AppCompatActivity {

    TextView textResult;
    int great;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game9result);

        //Objects.requireNonNull(getSupportActionBar()).hide();

        great = getIntent().getIntExtra("RA", 0);
        textResult = findViewById(R.id.textResult);

        textResult.setText("You answered "+ great + " / 10");

        ImageButton btn1 = findViewById(R.id.MenuButton);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Game9result.this, LevelSelect.class);
                startActivity(intent);
            }
        });

    }
}