package com.example.mainscreen;

//Win condition: Sort the number in ascending order


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Arrays;
import java.util.Random;

public class Game3 extends AppCompatActivity {

    private Button[] tiles;
    private TextView moveCounter;
    private TextView statusMessage;
    private Button shuffleButton;
    private int[] board = new int[9]; // 1 to 8 for tiles, 9 for empty
    private int moves = 0;
    private final int[] solvedBoard = {1, 2, 3, 4, 5, 6, 7, 8, 9};

    SharedPreferences userData, gameData;
    SharedPreferences.Editor gameDataEditor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game3);

        // Initialize UI elements
        moveCounter = findViewById(R.id.moveCounter);
        statusMessage = findViewById(R.id.statusMessage);
        shuffleButton = findViewById(R.id.shuffleButton);
        ImageButton btn1 = findViewById(R.id.MenuButton);
        tiles = new Button[]{
                findViewById(R.id.tile0),
                findViewById(R.id.tile1),
                findViewById(R.id.tile2),
                findViewById(R.id.tile3),
                findViewById(R.id.tile4),
                findViewById(R.id.tile5),
                findViewById(R.id.tile6),
                findViewById(R.id.tile7),
                findViewById(R.id.tile8)
        };

        userData = getSharedPreferences("User Data", MODE_PRIVATE);
        gameData = getSharedPreferences("Game Save Data", MODE_PRIVATE);

        for (int i = 0; i < tiles.length; i++) {
            final int index = i;
            tiles[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onTileClicked(index);
                }
            });
        }
        shuffleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shuffleBoard();
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Game3.this,LevelSelect.class);
                startActivity(i);
            }
        });

        // Initialize game
        shuffleBoard();
    }

    private void onTileClicked(int index) {
        // Find empty tile
        int emptyIndex = -1;
        for (int i = 0; i < board.length; i++) {
            if (board[i] == 9) {
                emptyIndex = i;
                break;
            }
        }

        // Check if clicked tile is adjacent to empty tile
        if (isAdjacent(index, emptyIndex)) {
            // Swap tiles
            board[emptyIndex] = board[index];
            board[index] = 9;
            moves++;
            updateUI();
            checkWin();
        }
    }

    private boolean isAdjacent(int index, int emptyIndex) {
        int row = index / 3;
        int col = index % 3;
        int emptyRow = emptyIndex / 3;
        int emptyCol = emptyIndex % 3;
        return (row == emptyRow && Math.abs(col - emptyCol) == 1) ||
                (col == emptyCol && Math.abs(row - emptyRow) == 1);
    }

    private void shuffleBoard() {
        moves = 0;
        statusMessage.setText("");
        // Initialize board
        for (int i = 0; i < board.length; i++) {
            board[i] = i + 1;
        }
        // Perform random valid moves to shuffle
        Random random = new Random();
        for (int i = 0; i < 100; i++) {
            int emptyIndex = -1;
            for (int j = 0; j < board.length; j++) {
                if (board[j] == 9) {
                    emptyIndex = j;
                    break;
                }
            }
            // Find valid neighbors
            java.util.ArrayList<Integer> neighbors = new java.util.ArrayList<>();
            if (emptyIndex - 3 >= 0) neighbors.add(emptyIndex - 3); // Up
            if (emptyIndex + 3 < 9) neighbors.add(emptyIndex + 3); // Down
            if (emptyIndex % 3 > 0) neighbors.add(emptyIndex - 1); // Left
            if (emptyIndex % 3 < 2) neighbors.add(emptyIndex + 1); // Right
            if (!neighbors.isEmpty()) {
                int swapIndex = neighbors.get(random.nextInt(neighbors.size()));
                board[emptyIndex] = board[swapIndex];
                board[swapIndex] = 9;
            }
        }
        updateUI();
    }

    private void updateUI() {
        for (int i = 0; i < tiles.length; i++) {
            int value = board[i];
            tiles[i].setText(value == 9 ? "" : String.valueOf(value));
            // Enable only adjacent tiles
            int emptyIndex = -1;
            for (int j = 0; j < board.length; j++) {
                if (board[j] == 9) {
                    emptyIndex = j;
                    break;
                }
            }
            tiles[i].setEnabled(isAdjacent(i, emptyIndex));
        }
        moveCounter.setText("Moves: " + moves);
    }

    private void checkWin() {
        if (Arrays.equals(board, solvedBoard)) {
            statusMessage.setText("You won in " + moves + " moves!");
            for (Button tile : tiles) {
                tile.setEnabled(false); // Disable further moves
            }

            if (gameData.getInt(userData.getString("Current User", "Guest")+"Stage", 0) < 3) {
                gameDataEditor = gameData.edit();

                gameDataEditor.putInt(userData.getString("Current User", "Guest") + "Stage", gameData.getInt(userData.getString("Current User", "Guest") + "Stage", 0) + 1);
                gameDataEditor.apply();
            }

        }
    }
}