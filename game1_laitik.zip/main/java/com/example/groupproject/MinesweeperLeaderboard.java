package com.example.groupproject;

import android.widget.ImageView;

import java.util.Comparator;

public class MinesweeperLeaderboard {
    private String name;
    private long time;

    MinesweeperLeaderboard(String name, long time){
        this.name = name;
        this.time = time;
    }

    public String getName(){
        return this.name;
    }

    public long getTime(){
        return this.time;
    }
}
