package com.example.groupproject;

import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class LeaderboardItemAdapter extends RecyclerView.Adapter<LeaderboardItemAdapter.ItemViewHolder> {

    private ArrayList<MinesweeperLeaderboard> dataList;
    private long time;

    LeaderboardItemAdapter(ArrayList<MinesweeperLeaderboard> dataList) {
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public LeaderboardItemAdapter.ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.leaderboard_list, parent, false);

        return new LeaderboardItemAdapter.ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LeaderboardItemAdapter.ItemViewHolder holder, int position) {
        String name = dataList.get(position).getName();
        long time = dataList.get(position).getTime();


        holder.userName.setText(name);
        holder.timeTaken.setText(String.valueOf(time));
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView userName;
        TextView timeTaken;

        ItemViewHolder(View nameView) {
            super(nameView);
            userName = nameView.findViewById(R.id.name);
            timeTaken = nameView.findViewById(R.id.time);
        }
    }
}
