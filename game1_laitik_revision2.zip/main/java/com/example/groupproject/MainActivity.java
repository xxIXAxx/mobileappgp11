package com.example.groupproject;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.IdRes;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, CompoundButton
        .OnCheckedChangeListener {

    int width, height, difficulty;

    private SharedPreferences gameData;
    private SharedPreferences.Editor gameDataEditor;

    Chronometer timer;
    LinearLayout mainGrid;
    boolean gameState;
    LinearLayout[] rows;

    long startTime, endTime;
    int[][] mineCount;
    boolean flagEnabled = false;
    boolean[][] cellFlagged;
    int flagCount;
    boolean[][] cellAppeared;

    TextView flagText;
    Switch flagSwitch;
    Button retryButton;
    Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        gameInitialization();
    }

    public void onClick(View view) {
        if (view.getId() == R.id.retry){
            mainGrid.removeAllViews();

            gameInitialization();
            return;
        }

        if (view.getId() == R.id.back){
            this.finish();
        }

        if (!gameState) {
            return;
        }

        onCellClicked(view);

    }

    private void onCellClicked(View view) {
        int cellID = view.getId();
        Button cellClicked = findViewById(view.getId());
        int row = cellID / 100;
        int col = cellID % 100;

        if (flagEnabled) {

            if (flagCount <= 0){
                return;
            }

            if (cellFlagged[row][col]) {
                flagCount++;
                cellFlagged[row][col] = false;
                cellClicked.setForeground(getDrawable(R.drawable.unmarkedcell));
            } else if (!cellAppeared[row][col]) {
                flagCount--;
                cellFlagged[row][col] = true;
                cellClicked.setForeground(getDrawable(R.drawable.cellflag));
            }
            flagText.setText(String.valueOf(flagCount));
            return;
        }

        if (!cellFlagged[row][col] && !cellAppeared[row][col]) {
            cellAppeared[row][col] = true;
            switch (mineCount[row][col]) {
                case 0:

                        @IdRes int cellOffset = 0;
                        cellClicked.setForeground(getDrawable(R.drawable.cellzero));

                        Button tempButton = findViewById(cellID);
                        cellOffset = 100; //Vertical
                        if (row != 0) {
                            cellClicked = findViewById(tempButton.getId() - cellOffset);
                            cellClicked.performClick();
                        }
                        if (row != height-1) {
                            cellClicked = findViewById(tempButton.getId() + cellOffset);
                            cellClicked.performClick();
                        }

                        cellOffset = 99; //Left-Bottom / Right-Up Corners

                        if (col != width-1 && row != 0) {
                            cellClicked = findViewById(tempButton.getId() - cellOffset);
                            cellClicked.performClick();
                        }
                        if (col != 0 && row != height-1) {
                            cellClicked = findViewById(tempButton.getId() + cellOffset);
                            cellClicked.performClick();
                        }

                        cellOffset = 101; //Left-Up/Right-Bottom Corners

                        if (col != 0 && row != 0) {
                            cellClicked = findViewById(tempButton.getId() - cellOffset);
                            cellClicked.performClick();
                        }

                        if (col != width-1 && row != height-1) {
                            cellClicked = findViewById(tempButton.getId() + cellOffset);
                            cellClicked.performClick();
                        }

                        cellOffset = 1; //Horizontal

                        if (col != 0) {
                            cellClicked = findViewById(tempButton.getId() - cellOffset);
                            cellClicked.performClick();
                        }

                        if (col != width-1) {
                            cellClicked = findViewById(tempButton.getId() + cellOffset);
                            cellClicked.performClick();
                        }
                    break;
                case 1:
                    cellClicked.setForeground(getDrawable(R.drawable.cellone));
                    break;
                case 2:
                    cellClicked.setForeground(getDrawable(R.drawable.celltwo));
                    break;
                case 3:
                    cellClicked.setForeground(getDrawable(R.drawable.cellthree));
                    break;
                case 4:
                    cellClicked.setForeground(getDrawable(R.drawable.cellfour));
                    break;
                case 5:
                    cellClicked.setForeground(getDrawable(R.drawable.cellfive));
                    break;
                case 6:
                    cellClicked.setForeground(getDrawable(R.drawable.cellsix));
                    break;
                case 7:
                    cellClicked.setForeground(getDrawable(R.drawable.cellseven));
                    break;
                case 8:
                    cellClicked.setForeground(getDrawable(R.drawable.celleight));
                    break;
                case 9:
                    flagSwitch.setEnabled(false);
                    cellClicked.setForeground(getDrawable(R.drawable.cellmine));
                    endGame();
                    break;
                default:
                    Log.d("Error", "Show mines");
            }
            checkFinish();
        }
    }

    private void checkFinish(){
        for (int r = 0; r < height; r++){
            for (int c = 0; c < width; c++){
                if (!cellAppeared[r][c] && mineCount[r][c] != 9){
                    return;
                }
            }
        }
        gameState = false;
        backButton.setVisibility(View.VISIBLE);
        backButton.setClickable(true);
        retryButton.setVisibility(View.VISIBLE);
        retryButton.setClickable(true);

        endTime = SystemClock.elapsedRealtime();
        gameData = getSharedPreferences("MinesweeperTime", MODE_PRIVATE);
        gameDataEditor = gameData.edit();

        if (difficulty != 3) { //Custom Grid will not be saved
            if (gameData.getLong(ProfileItemAdapter.currentUser + "MinesweeperTime" + difficulty, 0) != 0) {
                gameDataEditor.putLong(ProfileItemAdapter.currentUser + "MinesweeperTime" + difficulty, Math.min(endTime - startTime, gameData.getLong(ProfileItemAdapter.currentUser + "MinesweeperTime", 0)));
            } else {
                gameDataEditor.putLong(ProfileItemAdapter.currentUser + "MinesweeperTime" + difficulty, endTime - startTime);
            }
        }
        gameDataEditor.apply();

        timer.stop();
    }

    private void endGame() {
        gameState = false;
        timer.stop();
        Button mineCell;

        for (int r = 0; r < height; r++){
            for (int c = 0; c < width; c++){
                @IdRes int cellID = r*100+c;


                if (mineCount[r][c] == 9 && !cellAppeared[r][c] && !cellFlagged[r][c]){
                    mineCell = findViewById(cellID);
                    mineCell.setForeground(getDrawable(R.drawable.cellmine));
                    continue;
                }
                if (mineCount[r][c] != 9 && cellFlagged[r][c]){
                    mineCell = findViewById(cellID);
                    mineCell.setForeground(getDrawable(R.drawable.wrongflag));
                    continue;
                }
            }
        }

        backButton.setVisibility(View.VISIBLE);
        backButton.setClickable(true);
        retryButton.setVisibility(View.VISIBLE);
        retryButton.setClickable(true);
    }

    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (gameState) {
            if (isChecked) {
                buttonView.setForeground(getDrawable(R.drawable.flagenabled));
                flagEnabled = true;
            } else {
                buttonView.setForeground(getDrawable(R.drawable.flagdisabled));
                flagEnabled = false;
            }
        }
    }

    private void gameInitialization() {
        width = this.getIntent().getIntExtra("gridWidth", 0);
        height = this.getIntent().getIntExtra("gridHeight", 0);
        difficulty = this.getIntent().getIntExtra("difficultyChosen", 0);
        gameState = true;

        timer = findViewById(R.id.timer);
        flagText = findViewById(R.id.flagCount);
        rows = new LinearLayout[height];
        mineCount = new int[height][width];
        cellFlagged = new boolean[height][width];
        cellAppeared = new boolean[height][width];

        mainGrid = findViewById(R.id.main_grid);
        flagSwitch = findViewById(R.id.flagSwitch);
        backButton = findViewById(R.id.back);
        backButton.setVisibility(View.INVISIBLE);
        backButton.setClickable(false);
        backButton.setOnClickListener(this);

        flagSwitch.setEnabled(true);
        flagSwitch.setChecked(flagEnabled);
        flagSwitch.setOnCheckedChangeListener(this);
        flagSwitch.setForeground(getDrawable(R.drawable.flagdisabled));

        retryButton = findViewById(R.id.retry);
        retryButton.setVisibility(View.INVISIBLE);
        retryButton.setOnClickListener(this);
        retryButton.setClickable(false);
        retryButton.setForeground(getDrawable(R.drawable.retryicon));

        for (int r = 0; r < height; r++) {
            rows[r] = new LinearLayout(this);
            rows[r].setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < width; c++) {
                Button button = new Button(this);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(75, 75);
                button.setLayoutParams(params);
                button.setForeground(getDrawable(R.drawable.unmarkedcell));
                button.setId(r*100+c);
                button.setOnClickListener(this);
                mineCount[r][c] = 0;
                rows[r].addView(button);
            }
            mainGrid.addView(rows[r]);
        }

        gridInitialization();

        startTime = SystemClock.elapsedRealtime();
        timer.setBase(startTime);
        timer.start();
    }

    private void gridInitialization() {
        flagCount = 0;
        while (flagCount < 1) {
            int rowNum = (int) (Math.random() * (height-1) + 1);
            int colNum = (int) (Math.random() * (width-1) + 1);

            if (mineCount[rowNum][colNum] != 9) {
                mineCount[rowNum][colNum] = 9;
                flagCount++;
            }
        }
        flagText.setText(String.valueOf(flagCount));
        countMines();
    }

    private void countMines() {
        for (int r = 0; r < height; r++) {
            for (int c = 0; c < width; c++) {
                if (mineCount[r][c] == 9) {
                    continue;
                } else {
                    if (r - 1 >= 0) {
                        if (c - 1 >= 0) {
                            if (mineCount[r - 1][c - 1] == 9) {
                                mineCount[r][c]++;
                            }
                        }
                        if (c + 1 <= width-1) {
                            if (mineCount[r - 1][c + 1] == 9) {
                                mineCount[r][c]++;
                            }
                        }
                        if (mineCount[r - 1][c] == 9) {
                            mineCount[r][c]++;
                        }
                    }
                    if (r + 1 <= height-1) {
                        if (c - 1 >= 0) {
                            if (mineCount[r + 1][c - 1] == 9) {
                                mineCount[r][c]++;
                            }
                        }
                        if (c + 1 <= width-1) {
                            if (mineCount[r + 1][c + 1] == 9) {
                                mineCount[r][c]++;
                            }
                        }
                        if (mineCount[r + 1][c] == 9) {
                            mineCount[r][c]++;
                        }
                    }
                    if (c - 1 >= 0) {
                        if (mineCount[r][c - 1] == 9) {
                            mineCount[r][c]++;
                        }
                    }
                    if (c + 1 <= width-1) {
                        if (mineCount[r][c + 1] == 9) {
                            mineCount[r][c]++;
                        }
                    }
                }
            }
        }
    }
}