package com.example.groupproject;

import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Set;

public class Leaderboard extends AppCompatActivity implements View

        .OnClickListener, RadioGroup.OnCheckedChangeListener {

    private ArrayList<String> userList;
    private SharedPreferences userData, gameData;
    private RecyclerView leaderboardList;
    private LeaderboardItemAdapter leaderboardItemAdapter;

    private Button back;

    private RadioGroup difficultySelection;
    private RadioButton easyButton, mediumButton, hardButton;

    int difficulty;
    private ArrayList<MinesweeperLeaderboard> dataShown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_leaderboard);
        userList = new ArrayList<>();
        leaderboardList = findViewById(R.id.leaderboardList);
        leaderboardList.setLayoutManager(new LinearLayoutManager(this));

        userData = getSharedPreferences("Profile List", MODE_PRIVATE);
        gameData = getSharedPreferences("MinesweeperTime", MODE_PRIVATE);
        userList = new ArrayList<>(userData.getStringSet("Profile List", Set.copyOf(userList)));

        back = findViewById(R.id.back);
        back.setOnClickListener(this);

        easyButton = findViewById(R.id.easyButton);
        mediumButton = findViewById(R.id.mediumButton);
        hardButton = findViewById(R.id.hardButton);
        difficultySelection = findViewById(R.id.difficulty);
        difficultySelection.setOnCheckedChangeListener(this);

        dataShown = new ArrayList<>();
        for (String name : userList) {
            dataShown.add(new MinesweeperLeaderboard(name, gameData.getLong(name + "MinesweeperTime" + difficulty, 0)));
        }

        leaderboardItemAdapter = new LeaderboardItemAdapter(dataShown);
        leaderboardList.setAdapter(leaderboardItemAdapter);
    }

    public void onClick(View view) {
        if (view.getId() == R.id.back) {

            this.finish();
        }
    }

    public void onCheckedChanged(RadioGroup group, int checkedId) {
        RadioButton chosenDifficulty = group.findViewById(checkedId);

        if (chosenDifficulty == easyButton) {
            difficulty = 0;
        } else if (chosenDifficulty == mediumButton) {
            difficulty = 1;
        } else if (chosenDifficulty == hardButton) {
            difficulty = 2;
        }

        dataShown = new ArrayList<>();
        for (String name : userList) {
            dataShown.add(new MinesweeperLeaderboard(name, gameData.getLong(name + "MinesweeperTime" + difficulty, 0)));
        }

        dataShown.sort((obj1, obj2) -> {
            if (obj1.getTime() < obj2.getTime()) {
                return -1;
            } else if (obj1.getTime() > obj2.getTime()) {
                return 1;
            }
            return 0;
        });

        leaderboardItemAdapter = new LeaderboardItemAdapter(dataShown);
        leaderboardList.setAdapter(leaderboardItemAdapter);
        leaderboardItemAdapter.notifyDataSetChanged();
    }
}