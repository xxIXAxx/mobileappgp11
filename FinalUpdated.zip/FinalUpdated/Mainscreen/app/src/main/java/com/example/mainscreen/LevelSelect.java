package com.example.mainscreen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class LevelSelect extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener{

    GridView levelSelect;
    Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_level_select);

        levelSelect = findViewById(R.id.levelSelectGrid);
        levelSelect.setAdapter(new LevelSelectAdapter(this));

        back = findViewById(R.id.back);
        back.setOnClickListener(this);

        levelSelect.setOnItemClickListener(this);
    }

    public void onClick(View view){
        if (view == back){
            Intent intent =new Intent(this,MainActivity.class);
            startActivity(intent);
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        switch(position){
            case 0:
                Intent level1 = new Intent(this,Game1.class);
                startActivity(level1);
                break;
            case 1:
                Intent level2 = new Intent(this, Game2.class);
                startActivity(level2);
                break;
            case 2:
                Intent level3 = new Intent(this, Game3.class);
                startActivity(level3);
                break;
            case 3:
                Intent level4 = new Intent(this,Game4.class);
                startActivity(level4);
                break;
            case 4:
                Intent level5 = new Intent(this, Game5.class);
                startActivity(level5);
                break;
            case 5:
                Intent level6 = new Intent(this, Game6.class);
                startActivity(level6);
                break;
            case 6:
                Intent level7 = new Intent(this,Game8.class);

                startActivity(level7);
                break;
            case 7:
                Intent level8 = new Intent(this,Game7.class);
                level8.putExtra("Key1","Make little ");
                level8.putExtra("Key2","Ming happy!");
                startActivity(level8);
                break;
            case 8:
                Intent level11 = new Intent(this, Stage11.class);
                startActivity(level11);
                break;
            case 9:
                Intent level12 = new Intent(this, Stage12.class);

                startActivity(level12);
                break;
        }
    }
}