package com.example.mainscreen;

public class MathGameData {
    String name;
    int score;

    MathGameData(String name, int score){
        this.name = name;
        this.score = score;
    }

    public String getName(){
        return this.name;
    }

    public int getScore(){
        return this.score;
    }
}
