package com.example.mainscreen;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Stage11 extends AppCompatActivity implements View.OnClickListener, RadioGroup

        .OnCheckedChangeListener {

    private SharedPreferences userData;
    private SharedPreferences.Editor userDataEditor;

    RadioGroup difficultyChoice;
    RadioButton easyButton, mediumButton, hardButton, customButton;

    LinearLayout customSettings;

    String currentUser;

    Button widthDecrement, widthIncrement, heightDecrement, heightIncrement;
    Button confirmButton, backButton;

    TextView widthText, heightText, currentUserText;

    int customWidth = 10;
    int customHeight = 10;
    int width, height, difficulty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.stage11);

        userData = getSharedPreferences("User Data", MODE_PRIVATE);

        customSettings = findViewById(R.id.customSettings);
        customSettings.setVisibility(View.INVISIBLE);

        difficultyChoice = findViewById(R.id.difficultyChoice);
        easyButton = findViewById(R.id.easyButton);
        mediumButton = findViewById(R.id.mediumButton);
        hardButton = findViewById(R.id.hardButton);
        customButton = findViewById((R.id.customButton));

        backButton = findViewById(R.id.back);

        widthIncrement = findViewById(R.id.widthIncrement);
        widthDecrement = findViewById(R.id.widthDecrement);
        heightIncrement = findViewById(R.id.heightIncrement);
        heightDecrement = findViewById(R.id.heightDecrement);

        widthText = findViewById(R.id.width);
        heightText = findViewById(R.id.height);

        widthIncrement.setOnClickListener(this);
        widthDecrement.setOnClickListener(this);
        heightIncrement.setOnClickListener(this);
        heightDecrement.setOnClickListener(this);

        confirmButton = findViewById(R.id.confirm);
        confirmButton.setOnClickListener(this);

        backButton.setOnClickListener(this);
        difficultyChoice.setOnCheckedChangeListener(this);
    }

    public void onResume(){
        super.onResume();

        userData = getSharedPreferences("User Data", MODE_PRIVATE);
    }

    public void onClick(View view){
        if (view.getId() == R.id.back){
            this.finish();
            return;
        }

        if (view.getId() == R.id.confirm){
            Intent newGame = new Intent(this, MinesweeperGame.class);
            newGame.putExtra("gridWidth", width);
            newGame.putExtra("gridHeight", height);
            newGame.putExtra("difficultyChosen", difficulty);

            startActivity(newGame);
            return;
        }

        if (view.getId() == R.id.widthIncrement){
            if (customWidth < 12) {
                customWidth++;
            }
        }
        else if (view.getId() == R.id.widthDecrement){
            if (customWidth > 6){
                customWidth--;
            }
        }
        else if (view.getId() == R.id.heightIncrement){
            if (customHeight < 20){
                customHeight++;
            }
        }
        else if (view.getId() == R.id.heightDecrement){
            if (customHeight > 6){
                customHeight--;
            }
        }

        widthText.setText(String.valueOf(customWidth));
        heightText.setText(String.valueOf(customHeight));
        width = customWidth;
        height = customHeight;
    }

    public void onCheckedChanged(RadioGroup group, int checkedId){
        RadioButton chosenDifficulty = group.findViewById(checkedId);

        customSettings.setVisibility(View.INVISIBLE);

        if (chosenDifficulty.isChecked()){
            if (chosenDifficulty == easyButton){
                difficulty = 0;
                width = 10;
                height = 5;
                return;
            }
            if (chosenDifficulty == mediumButton){
                difficulty = 1;
                width = 12;
                height = 15;
                return;
            }
            if (chosenDifficulty == hardButton){
                difficulty = 2;
                width = 12;
                height = 20;
                return;
            }
            if (chosenDifficulty == customButton){
                difficulty = 3;
                customSettings.setVisibility(View.VISIBLE);
                return;
            }
        }
    }
}