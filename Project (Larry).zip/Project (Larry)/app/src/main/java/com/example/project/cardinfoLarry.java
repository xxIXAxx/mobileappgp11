package com.example.project;

public class cardinfoLarry {
    private int imageviewid;
    private int drawableid;
    private boolean isflipped = false;
    private boolean ismatched = false;

    public cardinfoLarry(int imageviewid, int drawableid){
        this.imageviewid = imageviewid;
        this.drawableid = drawableid;
    }

    public int getImageviewid() {
        return imageviewid;
    }

    public void setImageviewid(int imageviewid) {
        this.imageviewid = imageviewid;
    }

    public int getDrawableid() {
        return drawableid;
    }

    public void setDrawableid(int drawableid) {
        this.drawableid = drawableid;
    }

    public boolean isIsflipped() {
        return isflipped;
    }

    public void setIsflipped(boolean isflipped) {
        this.isflipped = isflipped;
    }

    public boolean isIsmatched() {
        return ismatched;
    }

    public void setIsmatched(boolean ismatched) {
        this.ismatched = ismatched;
    }

    @Override
    public String toString() {
        return "cardinfo{" +
                "imageviewid=" + imageviewid +
                ", drawableid=" + drawableid +
                ", isflipped=" + isflipped +
                ", ismatched=" + ismatched +
                '}';
    }
}
