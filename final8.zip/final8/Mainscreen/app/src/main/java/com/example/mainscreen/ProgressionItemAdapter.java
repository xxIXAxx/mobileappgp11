package com.example.mainscreen;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ProgressionItemAdapter extends RecyclerView.Adapter<ProgressionItemAdapter.ItemViewHolder> {

    private ArrayList<ProgressionData> dataList;

    ProgressionItemAdapter(ArrayList<ProgressionData> dataList) {
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public ProgressionItemAdapter.ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.progression_list, parent, false);

        return new ProgressionItemAdapter.ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProgressionItemAdapter.ItemViewHolder holder, int position) {
        String name = dataList.get(position).getName();
        int stage = dataList.get(position).getStage();

        holder.userName.setText(name);
        holder.stageProgressed.setText(String.valueOf(stage));
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {

        TextView userName, stageProgressed;

        ItemViewHolder(View nameView) {
            super(nameView);

            userName = nameView.findViewById(R.id.name);
            stageProgressed = nameView.findViewById(R.id.stage);
        }
    }
}
