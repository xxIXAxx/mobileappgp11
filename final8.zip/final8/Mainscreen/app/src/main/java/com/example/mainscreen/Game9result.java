package com.example.mainscreen;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Objects;

public class Game9result extends AppCompatActivity implements View.OnClickListener{

    TextView textResult;
    int great;

    SharedPreferences userData, gameData;
    SharedPreferences.Editor gameDataEditor;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game9result);

        //Objects.requireNonNull(getSupportActionBar()).hide();

        great = getIntent().getIntExtra("RA", 0);
        textResult = findViewById(R.id.textResult);

        textResult.setText("You answered "+ great + " / 10");

        ImageButton btn1 = findViewById(R.id.MenuButton);

        userData = getSharedPreferences("User Data", MODE_PRIVATE);
        gameData = getSharedPreferences("Game Save Data", MODE_PRIVATE);

        if (great >= 7) {
            if (gameData.getInt(userData.getString("Current User", "Guest") + "Stage", 0) < 9) {
                gameDataEditor = gameData.edit();

                gameDataEditor.putInt(userData.getString("Current User", "Guest") + "Stage", gameData.getInt(userData.getString("Current User", "Guest") + "Stage", 0) + 1);
                gameDataEditor.apply();
            }
        }
        btn1.setOnClickListener(this);

    }

    public void onClick(View view){
        if (view.getId() == R.id.MenuButton){
            this.finish();
        }
    }
}