package com.example.mainscreen;

//Win condition: Win against the "AI" [Turn on dark mode]


import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Game2 extends AppCompatActivity {

    private TextView textbox,aichoice;
    private UiModeManager uiModeManager;
    private Button rock, paper, scissors;
    private boolean isProcessing = false;
    private boolean win = false;
    private int losecount=0;
    private Handler handler = new Handler();

    SharedPreferences userData, gameData;
    SharedPreferences.Editor gameDataEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game2);
        textbox = findViewById(R.id.textbox);
        aichoice = findViewById(R.id.aichoice);
        rock = findViewById(R.id.rockButton);
        paper = findViewById(R.id.paperButton);
        scissors = findViewById(R.id.scissorsButton);
        ImageView imageView = findViewById(R.id.imageView2);

        userData = getSharedPreferences("User Data", MODE_PRIVATE);
        gameData = getSharedPreferences("Game Save Data", MODE_PRIVATE);

        findViewById(R.id.gomenu).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Game2.this, LevelSelect.class);
                startActivity(intent);
            }
        });

        uiModeManager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        boolean isDarkMode = isDarkModeEnabled(this);

        if (isDarkMode) {
            findViewById(R.id.main).setBackgroundColor(Color.BLACK);
            imageView.setImageResource(R.drawable.darkh302);
            textbox.setText("Oh no I can't look at your face, it was so dark");
        } else {
            findViewById(R.id.main).setBackgroundColor(Color.WHITE);
            imageView.setImageResource(R.drawable.lighth30);
        }

        rock.setOnClickListener(v -> handleButtonClick("Rock"));
        paper.setOnClickListener(v -> handleButtonClick("Paper"));
        scissors.setOnClickListener(v -> handleButtonClick("Scissors"));

    }

    private void handleButtonClick(String userChoice) {
        if (isProcessing || win) {
            return;
        }
        isProcessing = false;
        disableButtons();
        handler.postDelayed(() -> battle(userChoice), 300);
    }

    private void battle(String userChoice) {
        String aiChoice = isDarkModeEnabled(this) ? losechoice(userChoice) : winchoice(userChoice);
        String result;
        if (isWinningChoice(userChoice, aiChoice)) {
            aichoice.setText("I choose \n"+aiChoice);
            result = "You win! " + userChoice + " beats " + aiChoice;
            win = true;
            Intent intent = new Intent(Game2.this, LevelSelect.class);
            new Handler().postDelayed(() -> {startActivity(intent);
                Toast.makeText(this, "Remember to switch your device back to light mode", Toast.LENGTH_SHORT).show();
                }, 2000);

            if (gameData.getInt(userData.getString("Current User", "Guest")+"Stage", 0) < 2) {
                gameDataEditor = gameData.edit();
                gameDataEditor.putInt(userData.getString("Current User", "Guest") + "Stage", gameData.getInt(userData.getString("Current User", "Guest") + "Stage", 0) + 1);
                gameDataEditor.apply();
            }

        } else {
            aichoice.setText("I choose \n"+aiChoice);
            result = "You lose! " + aiChoice + " beats " + userChoice;
            win = false;
            losecount++;
            if (losecount==2){
                findViewById(R.id.hint).setVisibility(View.VISIBLE);}
        }

        textbox.setText(result);
        if (!win) {
            enableButtons();
        }
    }

    private boolean isWinningChoice(String userChoice, String aiChoice) {
        return (userChoice.equals("Rock") && aiChoice.equals("Scissors")) ||
                (userChoice.equals("Paper") && aiChoice.equals("Rock")) ||
                (userChoice.equals("Scissors") && aiChoice.equals("Paper"));
    }

    private void restartGame() {
        enableButtons();
        isProcessing = false;
        textbox.setText("");
        findViewById(R.id.hint).setVisibility(View.VISIBLE);
    }

    private void enableButtons() {
        rock.setEnabled(true);
        paper.setEnabled(true);
        scissors.setEnabled(true);
    }

    private void disableButtons() {
        rock.setEnabled(false);
        paper.setEnabled(false);
        scissors.setEnabled(false);
    }

    private String winchoice(String userChoice) {
        switch (userChoice) {
            case "Rock": return "Paper";
            case "Paper": return "Scissors";
            case "Scissors": return "Rock";
            default: return "";
        }
    }

    private String losechoice(String userChoice) {
        switch (userChoice) {
            case "Rock": return "Scissors";
            case "Paper": return "Rock";
            case "Scissors": return "Paper";
            default: return "";
        }
    }

    private boolean isDarkModeEnabled(Context context) {
        int currentNightMode = context.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return currentNightMode == Configuration.UI_MODE_NIGHT_YES;
    }
}