package com.example.mainscreen;

public class ProgressionData {

    private String name;
    private int stage;

    ProgressionData(String name, int stage) {
        this.name = name;
        this.stage = stage;
    }

    public String getName() {
        return this.name;
    }

    public int getStage(){
        return this.stage;
    }
}
