package com.example.mainscreen;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Button;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;


public class Leaderboard extends AppCompatActivity implements View

        .OnClickListener, RadioGroup.OnCheckedChangeListener {

    private ArrayList<String> userList = new ArrayList<>();
    private SharedPreferences userData, gameData;

    private RecyclerView leaderboardList;

    //Stage Progression List
    private ArrayList<ProgressionData> progressionData;
    private ProgressionItemAdapter progressionItemAdapter;

    //Minesweeper Time List
    private ArrayList<MinesweeperData> minesweeperData;
    private MinesweeperItemAdapter minesweeperItemAdapter;

    RadioGroup leaderboardType, minesweeperDifficulty;
    RadioButton stageProgressionButton, minesweeperButton, mathGameButton;
    RadioButton easyButton, mediumButton, hardButton;
    private LeaderboardAdapter leaderboardAdapter;
    Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_leaderboard);
        back = findViewById(R.id.back);
        back.setOnClickListener(this);

        leaderboardList = findViewById(R.id.leaderboardList);
        leaderboardList.setLayoutManager(new LinearLayoutManager(this));

        leaderboardType = findViewById(R.id.leaderboardType);
        minesweeperDifficulty = findViewById(R.id.minesweeperDifficulty);

        leaderboardType.setOnCheckedChangeListener(this);
        minesweeperDifficulty.setOnCheckedChangeListener(this);

        stageProgressionButton = findViewById(R.id.stageProgression);
        minesweeperButton = findViewById(R.id.minesweeperTime);

        easyButton = findViewById(R.id.easyDifficulty);
        mediumButton = findViewById(R.id.mediumDifficulty);
        hardButton = findViewById(R.id.hardDifficulty);

        //Get Data
        userData = getSharedPreferences("User Data", MODE_PRIVATE);
        userList = new ArrayList<>(userData.getStringSet("Profile List", Set.copyOf(userList)));
        gameData = getSharedPreferences("Game Save Data", MODE_PRIVATE);
        if (getIntent().hasExtra("NewUser")) {
            String userName = getIntent().getStringExtra("NewUser");
            addUserToScoreboard(userName);
        }

    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        RadioButton chosenButton = findViewById(checkedId);

        if (group == leaderboardType) {
            minesweeperDifficulty.setVisibility(View.INVISIBLE);
            if (chosenButton == stageProgressionButton) {
                ArrayList<ProgressionData> dataShown = new ArrayList<>();
                for (String name : userList) {

                    if (gameData.getInt(name + "Stage", 0) == 0) {
                        continue;
                    }

                    dataShown.add(new ProgressionData(name, gameData.getInt(name + "Stage", 0)));
                }

                dataShown.sort((obj1, obj2) -> {
                    if (obj1.getStage() > obj2.getStage()) {
                        return -1;
                    } else if (obj1.getStage() > obj2.getStage()) {
                        return 1;
                    }
                    return 0;
                });

                progressionItemAdapter = new ProgressionItemAdapter(dataShown);
                progressionItemAdapter.notifyDataSetChanged();
                leaderboardList.setAdapter(progressionItemAdapter);
                return;
            } else if (chosenButton == minesweeperButton) {
                minesweeperDifficulty.setVisibility(View.VISIBLE);
                return;
            }

            return;
        }
        if (group == minesweeperDifficulty) {

            ArrayList<MinesweeperData> dataShown = new ArrayList<>();

            if (chosenButton == easyButton) {
                for (String name : userList) {

                    if (gameData.getLong(name + "MinesweeperTime0", 0) == 0) {
                        continue;
                    }

                    dataShown.add(new MinesweeperData(name, gameData.getLong(name + "MinesweeperTime0", 0)));
                }
            } else if (chosenButton == mediumButton) {
                for (String name : userList) {

                    if (gameData.getLong(name + "MinesweeperTime1", 0) == 0) {
                        continue;
                    }

                    dataShown.add(new MinesweeperData(name, gameData.getLong(name + "MinesweeperTime1", 0)));
                }
            } else if (chosenButton == hardButton) {
                for (String name : userList) {

                    if (gameData.getLong(name + "MinesweeperTime2", 0) == 0) {
                        continue;
                    }

                    dataShown.add(new MinesweeperData(name, gameData.getLong(name + "MinesweeperTime2", 0)));
                }
            }

            dataShown.sort((obj1, obj2) -> {
                if (obj1.getTime() < obj2.getTime()) {
                    return -1;
                } else if (obj1.getTime() > obj2.getTime()) {
                    return 1;
                }
                return 0;
            });

            minesweeperItemAdapter = new MinesweeperItemAdapter(dataShown);
            minesweeperItemAdapter.notifyDataSetChanged();
            leaderboardList.setAdapter(minesweeperItemAdapter);
            return;
        }
    }

    @Override
    public void onClick(View view) {
        if (view == back) {
            this.finish();
        }
    }

    private void addUserToScoreboard(String userName) {
        // Update User Data
        userList.add(userName);
        userData.edit().putStringSet("Profile List", Set.copyOf(userList)).apply();

        // Add any initial game data for the new user (e.g., high score, progress data)
        gameData.edit().putInt(userName + "HighScore", 0).apply();
        // Add more game data as needed for the new user

        // Notify the leaderboard to update the list with the new user
        updateLeaderboard(); // You need to implement this method to update the displayed leaderboard
    }

    private void updateLeaderboard() {
        ArrayList<String> updatedUserList = new ArrayList<>(userData.getStringSet("Profile List", new HashSet<>()));

        // Update the leaderboard display based on the updated user list
        // You may need to retrieve and sort additional game data for the users

        // Update the RecyclerView adapter with the updated data
        // For example, if you have a custom adapter named leaderboardAdapter:
        if (leaderboardAdapter != null) {
            leaderboardAdapter.updateUserData(updatedUserList);
            leaderboardAdapter.notifyDataSetChanged();
        } else {
            // If leaderboardAdapter is not initialized, initialize it with the updated data
            leaderboardAdapter = new LeaderboardAdapter(updatedUserList);
            leaderboardList.setAdapter(leaderboardAdapter);
        }
    }
}