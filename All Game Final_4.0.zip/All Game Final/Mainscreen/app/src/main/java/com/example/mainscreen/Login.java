package com.example.mainscreen;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {

    private EditText userEditText;
    private EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userEditText = findViewById(R.id.user);
        passwordEditText = findViewById(R.id.ps);

        Button registerButton = findViewById(R.id.Register);
        registerButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view){
                Intent i = new Intent(Login.this,Creation.class);

                startActivity(i);
            }
        });

        Button loginButton = findViewById(R.id.Login);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });
        ImageButton btn1 = findViewById(R.id.MenuButton);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Login.this,MainActivity.class);
                startActivity(i);
            }
        });
    }



    private void loginUser() {
        String user = userEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (user.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }


        // Check if the user exists and the password is correct
        if (isValidUser(user, password)) {
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            // Navigate to the main activity

        } else {
            Toast.makeText(this, "Invalid email address or password", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidUser(String user, String password) {
        // Check if the user exists and the password is correct
//        SharedPreferences sharedPreferences = getSharedPreferences("UserAccountPrefs", MODE_PRIVATE);
//        Map<String, ?> allEntries = sharedPreferences.getAll();
//
//        for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
//            if (entry.getKey().contains("_email") && entry.getValue().equals(email)) {
//                String userKey = entry.getKey().substring(0, entry.getKey().indexOf("_email"));
//                String savedPassword = sharedPreferences.getString(userKey + "_password", "");
//                return savedPassword.equals(password);
//            }
//        }

        SharedPreferences userData = getSharedPreferences("User Data", MODE_PRIVATE);
        SharedPreferences.Editor userDataEditor = userData.edit();
        ArrayList<String> userList = new ArrayList<>();
        userList = new ArrayList<>(userData.getStringSet("Profile List", Set.copyOf(userList)));

        if (userList.indexOf(user) != -1){
            if (password.equals(userData.getString(user+"password", ""))){
                userDataEditor.putString("Current User", user);
                userDataEditor.apply();
                return true;
            }
        }

        return false;
    }


}