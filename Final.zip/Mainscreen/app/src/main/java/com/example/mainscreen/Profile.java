package com.example.mainscreen;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Set;

public class Profile extends AppCompatActivity implements View

        .OnClickListener{

    private RecyclerView profileList;
    private ProfileItemAdapter profileItemAdapter;
    private ArrayList<String> nameList = new ArrayList<>();

    private SharedPreferences profileData;
    private SharedPreferences.Editor profileDataEditor;

    RelativeLayout addProfilePopup;
    Button backButton, addProfileButton, confirmAdd, popupBack;
    EditText newProfileNameEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);
        profileData = getSharedPreferences("User Data", MODE_PRIVATE);
        nameList = new ArrayList<>(profileData.getStringSet("Profile List", Set.copyOf(nameList)));

        addProfilePopup = findViewById(R.id.addProfilePopup);
        addProfilePopup.setVisibility(View.INVISIBLE);

        profileList = findViewById(R.id.profileList);
        profileList.setLayoutManager(new LinearLayoutManager(this));


        backButton = findViewById(R.id.back);
        backButton.setOnClickListener(this);
        addProfileButton = findViewById(R.id.addProfile);
        addProfileButton.setOnClickListener(this);
        popupBack = findViewById(R.id.popupBack);
        popupBack.setOnClickListener(this);

        confirmAdd = findViewById(R.id.confirmAdd);
        confirmAdd.setOnClickListener(this);

        newProfileNameEdit = findViewById(R.id.editProfileName);
        profileItemAdapter = new ProfileItemAdapter(nameList);
        profileList.setAdapter(profileItemAdapter);

    }

    public void onClick(View view){
        if (view.getId() == R.id.back){
            profileDataEditor = profileData.edit();

            profileDataEditor.putString("Current User", profileItemAdapter.currentUser);
            profileDataEditor.apply();

            this.finish();
        }
        if (view.getId() == R.id.addProfile){
            addProfilePopup.setVisibility(View.VISIBLE);
            backButton.setClickable(false);
            addProfileButton.setClickable(false);
        }
        if(view.getId() == R.id.popupBack){
            addProfilePopup.setVisibility(View.INVISIBLE);
            backButton.setClickable(true);
            addProfileButton.setClickable(true);
            newProfileNameEdit.setText("");
        }
        if (view.getId() == R.id.confirmAdd){
            if (!String.valueOf(newProfileNameEdit.getText()).isBlank()) {
                profileData = getSharedPreferences("User Data", MODE_PRIVATE);
                profileDataEditor = profileData.edit();

                nameList.add(String.valueOf(newProfileNameEdit.getText()));

                addProfilePopup.setVisibility(View.INVISIBLE);
                backButton.setClickable(true);
                addProfileButton.setClickable(true);
                newProfileNameEdit.setText("");

                profileDataEditor.putStringSet("Profile List", Set.copyOf(nameList));
                profileItemAdapter.notifyDataSetChanged();

                profileDataEditor.apply();
            }
        }
    }
}