package com.example.mainscreen;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MathGameItemAdapter extends RecyclerView.Adapter<MathGameItemAdapter.ItemViewHolder> {

    private ArrayList<MathGameData> dataList;

    MathGameItemAdapter(ArrayList<MathGameData> dataList) {
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public MathGameItemAdapter.ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.mathgame_list, parent, false);

        return new MathGameItemAdapter.ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MathGameItemAdapter.ItemViewHolder holder, int position) {
        String name = dataList.get(position).getName();
        int score = dataList.get(position).getScore();

        holder.userName.setText(name);
        holder.highScore.setText(String.valueOf(score));
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {

        TextView userName, highScore;

        ItemViewHolder(View nameView) {
            super(nameView);

            userName = nameView.findViewById(R.id.name);
            highScore = nameView.findViewById(R.id.score);
        }
    }
}
