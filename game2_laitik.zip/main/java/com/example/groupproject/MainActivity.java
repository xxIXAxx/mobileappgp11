package com.example.groupproject;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

import kotlinx.coroutines.channels.ChannelResult;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private int scoreValue, highScoreValue;
    private int num1, num2, operator;
    private int[] buttonList = new int[10];
    private boolean gameState = true;
    private RelativeLayout popupEnd;

    private TextView score, expression, answer, highScore;
    private String expressionText;
    private Button buttonNeg;
    private Button button1, button2, button3;
    private Button button4, button5, button6;
    private Button button7, button8, button9;
    private Button buttonClear, button0, buttonEnter;
    private Button buttonBack, buttonRetry;

    private Chronometer timerText;
    private SharedPreferences appStorage;
    private SharedPreferences.Editor storageEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        timerText = findViewById(R.id.countdownTimer);
        popupEnd = findViewById(R.id.endPopup);
        popupEnd.setVisibility(View.INVISIBLE);

        buttonNeg = findViewById(R.id.buttonNegative);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);
        button0 = findViewById(R.id.button0);
        buttonClear = findViewById(R.id.buttonClear);
        buttonEnter = findViewById(R.id.buttonEnter);

        buttonBack = findViewById(R.id.popupBack);
        buttonRetry = findViewById(R.id.retry);

        loadResources();
        loadUI();
        setupTimer();
    }

    private boolean checkAnswer(TextView expression) {
        switch (operator) {
            case 0:
                if (Integer.parseInt((String) answer.getText()) == num1 + num2) {
                    return true;
                }
            case 1:
                if (Integer.parseInt((String) answer.getText()) == num1 - num2) {
                    return true;
                }
            case 2:
                if (Integer.parseInt((String) answer.getText()) == num1 * num2) {
                    return true;
                }
            case 3:
                if (Integer.parseInt((String) answer.getText()) == num1 / num2) {
                    return true;
                }
        }
        return false;
    }

    private String generateExpression() {
        num1 = new Random().nextInt(10);
        num2 = new Random().nextInt(10);
        operator = new Random().nextInt(4);

        //Log.d("Operator", String.valueOf(operator));

        storageEditor = appStorage.edit();
        storageEditor.putInt("Number1", num1);
        storageEditor.putInt("Number2", num2);
        storageEditor.putInt("Operator", operator);
        storageEditor.apply();

        switch (operator) {
            case 0: //Addition
                return String.format("%d + %d = ???", num1, num2);
            case 1:
                return String.format("%d - %d = ???", num1, num2);
            case 2:
                return String.format("%d * %d = ???", num1, num2);
            case 3:
                if (num2 == 0) {
                    num2 = 1;
                    storageEditor.putInt("Number2", num2);
                    storageEditor.apply();
                }
                return String.format("%d // %d = ???", num1, num2);
        }
        return "Error";
    }

    public void onResume() {
        super.onResume();

        num1 = appStorage.getInt("Number1", 0);
        num2 = appStorage.getInt("Number2", 0);
        operator = appStorage.getInt("Operator", 0);
    }

    public void onPause() {
        super.onPause();

        storageEditor = appStorage.edit();
        storageEditor.putInt("Score", scoreValue);
        storageEditor.putString("Expression", (String) expressionText);
        storageEditor.apply();
    }

    public void onStop() {
        super.onStop();

        storageEditor = appStorage.edit();
        storageEditor.putInt("HighScore", Math.max(scoreValue, appStorage.getInt("HighScore", 0)));
        storageEditor.putInt("Score", 0);
        storageEditor.apply();
    }

    public void onClick(View view) {
        if (!gameState){
            if (view.getId() == R.id.popupBack){
                this.finish();
            } else if (view.getId() == R.id.retry){
                loadResources();
                setupTimer();
                popupEnd.setVisibility(View.INVISIBLE);

                gameState = true;
            } else if (view.getId() == R.id.next){
                this.finish(); //Intent
            }
            return;
        }

        if (view.getId() == R.id.button1) {
            if (answer.getText().equals("0")) {
                answer.setText("");
            }
            answer.setText(answer.getText() + String.valueOf(buttonList[1]));
        } else if (view.getId() == R.id.button2) {
            if (answer.getText().equals("0")) {
                answer.setText("");
            }
            answer.setText(answer.getText() + String.valueOf(buttonList[2]));
        } else if (view.getId() == R.id.button3) {
            if (answer.getText().equals("0")) {
                answer.setText("");
            }
            answer.setText(answer.getText() + String.valueOf(buttonList[3]));
        } else if (view.getId() == R.id.button4) {
            if (answer.getText().equals("0")) {
                answer.setText("");
            }
            answer.setText(answer.getText() + String.valueOf(buttonList[4]));
        } else if (view.getId() == R.id.button5) {
            if (answer.getText().equals("0")) {
                answer.setText("");
            }
            answer.setText(answer.getText() + String.valueOf(buttonList[5]));
        } else if (view.getId() == R.id.button6) {
            if (answer.getText().equals("0")) {
                answer.setText("");
            }
            answer.setText(answer.getText() + String.valueOf(buttonList[6]));
        } else if (view.getId() == R.id.button7) {
            if (answer.getText().equals("0")) {
                answer.setText("");
            }
            answer.setText(answer.getText() + String.valueOf(buttonList[7]));
        } else if (view.getId() == R.id.button8) {
            if (answer.getText().equals("0")) {
                answer.setText("");
            }
            answer.setText(answer.getText() + String.valueOf(buttonList[8]));
        } else if (view.getId() == R.id.button9) {
            if (answer.getText().equals("0")) {
                answer.setText("");
            }
            answer.setText(answer.getText() + String.valueOf(buttonList[9]));
        } else if (view.getId() == R.id.button0) {
            if (answer.getText().equals("0")) {
                answer.setText("");
            }
            answer.setText(answer.getText() + String.valueOf(buttonList[0]));
        } else if (view.getId() == R.id.buttonClear) {
            answer.setText("");
        } else if (view.getId() == R.id.buttonEnter) {
            if (checkAnswer(expression)) {
                ++scoreValue;
                score.setText(String.valueOf(scoreValue));
                expression.setText(generateExpression());
                answer.setText("");
            }
        } else if (view.getId() == R.id.buttonNegative) {
            if (answer.getText().equals("")) {
                answer.setText("0");
            }
            answer.setText(String.valueOf(-Integer.parseInt((String) answer.getText())));
        }
    }

    private void loadResources() {
        appStorage = getSharedPreferences("Game", MODE_PRIVATE);
        scoreValue = appStorage.getInt("Score", 0);
        highScoreValue = appStorage.getInt("HighScore", 0);

        score = findViewById(R.id.score);
        highScore = findViewById(R.id.highScore);
        expression = findViewById(R.id.expression);
        answer = findViewById(R.id.answer);

        expression.setText(generateExpression());

        //Log.d("Debug",(String)expression.getText());
        expressionText = appStorage.getString("Expression", (String) expression.getText());
        answer.setText("");
        score.setText(String.valueOf(scoreValue));
        highScore.setText(String.valueOf(highScoreValue));
    }

    private void loadUI() {
        for (int i = 0; i < 10; i++) {
            buttonList[i] = i;
        }

        buttonNeg.setOnClickListener(this);
        button0.setOnClickListener(this);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        button6.setOnClickListener(this);
        button7.setOnClickListener(this);
        button8.setOnClickListener(this);
        button9.setOnClickListener(this);
        buttonClear.setOnClickListener(this);
        buttonEnter.setOnClickListener(this);

        buttonBack.setOnClickListener(this);
        buttonRetry.setOnClickListener(this);
    }

    public void setupTimer(){
        int time = 10_000;
        timerText.setBase(SystemClock.elapsedRealtime() + time);

        CountDownTimer countdownTimer = new CountDownTimer(time, 1000) {
            @Override
            public void onTick(long l) {
                timerText.setBase(SystemClock.elapsedRealtime() + l);
                return;
            }

            @Override
            public void onFinish() {
                gameState = false;
                popupEnd.setVisibility(View.VISIBLE);

                TextView finalScore = findViewById(R.id.finalScore);
                finalScore.setText(String.valueOf(scoreValue));

                TextView popupHighScore = findViewById(R.id.popupHighScore);
                popupHighScore.setText(String.valueOf(Math.max(scoreValue, highScoreValue)));


                storageEditor = appStorage.edit();
                storageEditor.putInt("HighScore", Math.max(scoreValue, appStorage.getInt("HighScore", 0)));
                storageEditor.putInt("Score", 0);
                storageEditor.apply();
            }
        };

        countdownTimer.start();
    }
}