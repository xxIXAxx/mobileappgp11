package com.example.mainscreen;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

public class LevelSelectAdapter extends BaseAdapter {
    private Context context;
    private int levelUnlocked;

    LevelSelectAdapter(Context context, int levelUnlocked) {
        this.context = context;
        this.levelUnlocked = levelUnlocked;
    }


    @Override
    public int getCount() {
        return levelImage.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView levelView;

        if (convertView == null) {
            levelView = new ImageView(context);
            levelView.setLayoutParams(new ViewGroup.LayoutParams(300, 300));
        } else {
            levelView = (ImageView) convertView;
        }
        if (levelUnlocked+1 > position) {
            levelView.setImageResource(levelImage[position]);
        } else {
            levelView.setImageResource(R.drawable.locked);
        }
        return levelView;
    }

    public int[] levelImage = {
            R.drawable.stage1, R.drawable.stage2,
            R.drawable.stage3, R.drawable.stage4,
            R.drawable.stage5, R.drawable.stage6,
            R.drawable.stage7, R.drawable.stage8,
            R.drawable.stage9, R.drawable.stage10,
            R.drawable.stage11, R.drawable.stage12,
    };
}
