package com.example.mainscreen;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class LevelSelect extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener{

    GridView levelSelect;
    Button back;

    SharedPreferences userData, gameData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_level_select);
        userData = getSharedPreferences("User Data", MODE_PRIVATE);
        gameData = getSharedPreferences("Game Save Data", MODE_PRIVATE);

        levelSelect = findViewById(R.id.levelSelectGrid);
        levelSelect.setAdapter(new LevelSelectAdapter(this, gameData.getInt(userData.getString("Current User", "Guest")+"Stage", 0)));

        back = findViewById(R.id.back);
        back.setOnClickListener(this);

        levelSelect.setOnItemClickListener(this);
    }

    public void onClick(View view){
        if (view == back){
            Intent intent =new Intent(this,MainActivity.class);
            startActivity(intent);
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        switch(position){
            case 0:
                Intent level1 = new Intent(this,Game1.class);
                startActivity(level1);
                break;
            case 1:
                if (gameData.getInt(userData.getString("Current User", "Guest")+"Stage", 0) < 1) {
                    return;
                }
                Intent level2 = new Intent(this, Game2.class);
                startActivity(level2);
                break;
            case 2:
                if (gameData.getInt(userData.getString("Current User", "Guest")+"Stage", 0) < 2) {
                    return;
                }
                Intent level3 = new Intent(this, Game3.class);
                startActivity(level3);
                break;
            case 3:
                if (gameData.getInt(userData.getString("Current User", "Guest")+"Stage", 0) < 3) {
                    return;
                }
                Intent level4 = new Intent(this,Game4.class);
                startActivity(level4);
                break;
            case 4:
                if (gameData.getInt(userData.getString("Current User", "Guest")+"Stage", 0) < 4) {
                    return;
                }
                Intent level5 = new Intent(this, Game5.class);
                startActivity(level5);
                break;
            case 5:
                if (gameData.getInt(userData.getString("Current User", "Guest")+"Stage", 0) < 5) {
                    return;
                }
                Intent level6 = new Intent(this, Game6.class);
                startActivity(level6);
                break;
            case 6:
                if (gameData.getInt(userData.getString("Current User", "Guest")+"Stage", 0) < 6) {
                    return;
                }
                Intent level7 = new Intent(this,Game8.class);

                startActivity(level7);
                break;
            case 7:
                if (gameData.getInt(userData.getString("Current User", "Guest")+"Stage", 0) < 7) {
                    return;
                }
                Intent level8 = new Intent(this,Game7.class);
                level8.putExtra("Key1","Make little ");
                level8.putExtra("Key2","Ming happy!");
                startActivity(level8);
                break;
            case 8:
                if (gameData.getInt(userData.getString("Current User", "Guest")+"Stage", 0) < 8) {
                    return;
                }
                Intent level11 = new Intent(this, Stage11.class);
                startActivity(level11);
                break;
            case 9:
                if (gameData.getInt(userData.getString("Current User", "Guest")+"Stage", 0) < 9) {
                    return;
                }
                Intent level12 = new Intent(this, Stage12.class);

                startActivity(level12);
                break;
        }
    }
}