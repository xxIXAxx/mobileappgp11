package com.example.mainscreen;

//Win condition: Score at least 35 in a minute


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class Game4 extends AppCompatActivity {

    private TextView scoreText, timeText;
    private ImageView animeImage;
    private Button restartButton,menubutton,nextlevelbutton;
    private int score = 0;
    private int timeLeft = 30;
    private boolean isGameRunning = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();

    SharedPreferences userData, gameData;
    SharedPreferences.Editor gameDataEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game4);

        // Initialize views
        scoreText = findViewById(R.id.scoreText);
        timeText = findViewById(R.id.timeText);
        animeImage = findViewById(R.id.animeImage);
        restartButton = findViewById(R.id.restartButton);
        menubutton = findViewById(R.id.mainmenu);
        nextlevelbutton = findViewById(R.id.nextpage);

        userData = getSharedPreferences("User Data", MODE_PRIVATE);
        gameData = getSharedPreferences("Game Save Data", MODE_PRIVATE);

        // Start the game
        startGame();

        // Handle image tap
        animeImage.setOnClickListener(v -> {
            if (isGameRunning) {
                animeImage.animate().scaleX(1.2f).scaleY(1.2f).setDuration(100).withEndAction(() -> animeImage.animate().scaleX(1f).scaleY(1f).setDuration(100)).start();
                score++;
                scoreText.setText("Score: " + score);
                moveImageToRandomPosition();
            }
        });

        // Handle restart button
        restartButton.setOnClickListener(v -> startGame());

        menubutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Game4.this, LevelSelect.class);
                startActivity(intent);

            }
        });

        nextlevelbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Game4.this,Game5.class);
                startActivity(intent);

            }
        });


    }

    private void startGame() {
        score = 0;
        timeLeft = 30;
        isGameRunning = true;
        scoreText.setText("Score: 0");
        timeText.setText("Time: 30");
        animeImage.setVisibility(View.VISIBLE);
        restartButton.setVisibility(View.GONE);
        // Reset image position to center (rely on XML layout)
        animeImage.setX(0);
        animeImage.setY(0);
        // Ensure layout parameters center the image
        animeImage.requestLayout();
        startTimer();
    }

    private void moveImageToRandomPosition() {
        // Get screen dimensions
        int screenWidth = getResources().getDisplayMetrics().widthPixels - animeImage.getWidth();
        int screenHeight = getResources().getDisplayMetrics().heightPixels - animeImage.getHeight() - 100; // Adjust for status bar and padding

        // Calculate random position
        float x = random.nextInt(Math.max(1, screenWidth));
        float y = random.nextInt(Math.max(1, screenHeight));

        // Move image
        animeImage.setX(x);
        animeImage.setY(y);
    }

    private void startTimer() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isGameRunning) {
                    timeLeft--;
                    timeText.setText("Time: " + timeLeft);
                    if (timeLeft <= 0) {
                        endGame();
                    } else {
                        handler.postDelayed(this, 1000);
                    }
                }
            }
        }, 1000);
    }

    private void endGame() {
        isGameRunning = false;
        animeImage.setVisibility(View.GONE);
        restartButton.setVisibility(View.VISIBLE);
        menubutton.setVisibility(View.VISIBLE);
        scoreText.setText("Game Over! Score: " + score);

        if (score >= 35){
            nextlevelbutton.setVisibility(View.VISIBLE);
            if (gameData.getInt(userData.getString("Current User", "Guest")+"Stage", 0) < 4) {
                gameDataEditor = gameData.edit();

                gameDataEditor.putInt(userData.getString("Current User", "Guest") + "Stage", gameData.getInt(userData.getString("Current User", "Guest") + "Stage", 0) + 1);
                gameDataEditor.apply();
            }

        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null); // Prevent memory leaks
    }
}