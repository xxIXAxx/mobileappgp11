package com.example.mainscreen;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

//Important SharedPreferences Name
//File: User Data
//Key: Current User : String
//Key: Profile List : Set<String> - Refer to Leaderboard.java Line 73 to convert Set to ArrayList lol

//File: Game Save Data
//Key: [UserName] + Stage : int
//Key: [UserName] + MinesweeperTime[0..2] : long
//Key: [UserName] + HighScore : int


public class MainActivity extends AppCompatActivity implements View

        .OnClickListener{

    SharedPreferences dataStorage;
    SharedPreferences.Editor dataEditor;

    Button profile, leaderboard, play;
    TextView currentUserText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        dataStorage = getSharedPreferences("User Data", MODE_PRIVATE);
        String currentUser = dataStorage.getString("Current User", "Guest");

        profile = findViewById(R.id.profile);
        leaderboard = findViewById(R.id.leaderboard);
        play = findViewById(R.id.play);

        profile.setOnClickListener(this);
        leaderboard.setOnClickListener(this);
        play.setOnClickListener(this);

        currentUserText = findViewById(R.id.currentUser);
        currentUserText.setText(ProfileItemAdapter.currentUser);
    }

    public void onResume(){
        super.onResume();

        currentUserText.setText(ProfileItemAdapter.currentUser);
    }

    public void onClick(View view){
        if (view == profile){
            Intent profileIntent = new Intent(this, Profile.class);

            startActivity(profileIntent);
            return;
        }
        if (view == play){
            Intent levelSelectIntent = new Intent(this, LevelSelect.class);

            startActivity(levelSelectIntent);
            return;
        }
        if (view == leaderboard){
            Intent leaderboardIntent = new Intent(this, Leaderboard.class);

            startActivity(leaderboardIntent);
            return;
        }
    }
}