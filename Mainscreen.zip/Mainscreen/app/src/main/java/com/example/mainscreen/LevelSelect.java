package com.example.mainscreen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class LevelSelect extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener{

    GridView levelSelect;
    Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_level_select);

        levelSelect = findViewById(R.id.levelSelectGrid);
        levelSelect.setAdapter(new LevelSelectAdapter(this));

        back = findViewById(R.id.back);
        back.setOnClickListener(this);

        levelSelect.setOnItemClickListener(this);
    }

    public void onClick(View view){
        if (view == back){
            this.finish();
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        switch(position){
            case 10:
                Intent level11 = new Intent(this, Stage11.class);

                startActivity(level11);
                break;
            case 11:
                Intent level12 = new Intent(this, Stage12.class);

                startActivity(level12);
                break;
        }
    }
}