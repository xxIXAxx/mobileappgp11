package com.example.mainscreen;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ProfileItemAdapter extends RecyclerView.Adapter<ProfileItemAdapter.ItemViewHolder> {
    private ArrayList<String> nameList;
    public static String currentUser;

    ProfileItemAdapter(ArrayList<String> nameList){
        this.nameList = nameList;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.profile_list, parent, false);

        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position){
        String name = nameList.get(position);

        holder.profileName.setText(name);
        holder.profileName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentUser = name;
            }
        });
    }

    @Override
    public int getItemCount(){
        return nameList.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder{
        TextView profileName;

        ItemViewHolder(View nameView){
            super(nameView);
            profileName = nameView.findViewById(R.id.profileNameText);
        }
    }
}
