package com.example.mainscreen;

//Win condition: Defeat Kaido


import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Game5 extends AppCompatActivity {

    private ImageView draggableImage, targetImage,targetImage2,nika,draggableImage2;
    private float dX, dY;
    private float originalX, originalY;
    TextView hpcounter,kaidohp;
    private int hp=100,hp2 =100, counter = 0;

    SharedPreferences userData, gameData;
    SharedPreferences.Editor gameDataEditor;
    ImageView tick;

    @SuppressLint({"ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game5);
        hpcounter = findViewById(R.id.luffyhp);
        kaidohp = findViewById(R.id.kaidohp);
        draggableImage = findViewById(R.id.kaidoweapon);
        targetImage = findViewById(R.id.luffy);
        targetImage2 = findViewById(R.id.kaido);
        nika = findViewById(R.id.nika);
        draggableImage2 = findViewById(R.id.luffyfist);
        ImageButton btn1 = findViewById(R.id.MenuButton);
        tick = findViewById(R.id.imageView);

        userData = getSharedPreferences("User Data", MODE_PRIVATE);
        gameData = getSharedPreferences("Game Save Data", MODE_PRIVATE);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Game5.this,LevelSelect.class);
                startActivity(i);
            }
        });

        draggableImage.post(() -> {
            originalX = draggableImage.getX();
            originalY = draggableImage.getY();
        });

        draggableImage2.post(() -> {
            originalX = draggableImage.getX();
            originalY = draggableImage.getY();
        });

        draggableImage.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dX = v.getX() - event.getRawX();
                    dY = v.getY() - event.getRawY();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    v.animate()
                            .x(event.getRawX() + dX)
                            .y(event.getRawY() + dY)
                            .setDuration(0)
                            .start();
                    return true;

                case MotionEvent.ACTION_UP:
                    if (isViewOverlapping(draggableImage, targetImage)) {
                        hp-=50;
                        hpcounter.setText("HP: " + hp +"%");
                        if (hp == 0){
                            hp = 100;
                            targetImage.setVisibility(View.INVISIBLE);
                            nika.setVisibility(View.VISIBLE);
                            draggableImage2.setVisibility(View.VISIBLE);
                            draggableImage.setVisibility(View.INVISIBLE);
                            hpcounter.setText("HP: " + hp+"%");
                        }

                    }
                    else if (isViewOverlapping(draggableImage,targetImage2)){
                        Toast.makeText(this,"How dare you use his own magic against him?",Toast.LENGTH_LONG).show();
                    }

                    // Animate back to original position
                    v.animate()
                            .x(originalX)
                            .y(originalY)
                            .setDuration(300)
                            .start();

                    return true;
            }
            return false;
        });


        draggableImage2.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dX = v.getX() - event.getRawX();
                    dY = v.getY() - event.getRawY();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    v.animate()
                            .x(event.getRawX() + dX)
                            .y(event.getRawY() + dY)
                            .setDuration(0)
                            .start();
                    return true;

                case MotionEvent.ACTION_UP:
                    if (isViewOverlapping(draggableImage2, targetImage2)) {
                        hp2-=50;
                        kaidohp.setText("HP: " + hp2 +"%");
                        if (hp2==0){
                            tick.setVisibility(View.VISIBLE);
                            btn1.setVisibility(View.VISIBLE);

                            if (gameData.getInt(userData.getString("Current User", "Guest")+"Stage", 0) < 5) {
                                gameDataEditor = gameData.edit();

                                gameDataEditor.putInt(userData.getString("Current User", "Guest") + "Stage", gameData.getInt(userData.getString("Current User", "Guest") + "Stage", 0) + 1);
                                gameDataEditor.apply();
                            }

                        }
                    }
                    else if (isViewOverlapping(draggableImage2,targetImage)){
                        Toast.makeText(this,"How dare you use his own magic against him?",Toast.LENGTH_LONG).show();
                    }

                    // Animate back to original position
                    v.animate()
                            .x(originalX)
                            .y(originalY)
                            .setDuration(300)
                            .start();

                    return true;
            }
            return false;
        });



    }


    private boolean isViewOverlapping(View view1, View view2) {
        int[] pos1 = new int[2];
        int[] pos2 = new int[2];

        view1.getLocationOnScreen(pos1);
        view2.getLocationOnScreen(pos2);

        Rect rect1 = new Rect(pos1[0], pos1[1],
                pos1[0] + view1.getWidth(), pos1[1] + view1.getHeight());

        Rect rect2 = new Rect(pos2[0], pos2[1],
                pos2[0] + view2.getWidth(), pos2[1] + view2.getHeight());

        return Rect.intersects(rect1, rect2);
    }
}