package com.example.mainscreen;

public class MinesweeperData {
    private String name;
    private long time;

    MinesweeperData(String name, long time){
        this.name = name;
        this.time = time;
    }

    public String getName(){
        return this.name;
    }

    public long getTime(){
        return this.time;
    }
}
