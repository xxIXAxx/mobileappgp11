package com.example.mainscreen;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;


import java.util.Arrays;
import java.util.Collections;


    public class Game10 extends AppCompatActivity {

        private GridLayout gridLayout;
        private TextView tvWinMessage;
        private Button[] cards;
        private int[] cardImages = {R.drawable.card1, R.drawable.card2, R.drawable.card3,
                R.drawable.card4, R.drawable.card5, R.drawable.card6};
        private int[] cardBack = {R.drawable.card_back};
        private int[] cardArray;

        private int firstCard = -1;
        private int secondCard = -1;
        private boolean isBusy = false;
        private int matchedPairs = 0;
        private final int TOTAL_PAIRS = 6;

        SharedPreferences userData, gameData;
        SharedPreferences.Editor gameDataEditor;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_game10);

            gridLayout = findViewById(R.id.gridLayout);
            tvWinMessage = findViewById(R.id.tvWinMessage);
            initializeGame();
            shuffleAndResetGame();

            ImageButton btn1 = findViewById(R.id.imageButton);
            btn1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Game10.this,LevelSelect.class);
                    startActivity(i);
                }
            });

            userData = getSharedPreferences("User Data", MODE_PRIVATE);
            gameData = getSharedPreferences("Game Save Data", MODE_PRIVATE);
        }

        private void initializeGame() {
            // Create pairs of cards
            cardArray = new int[12];
            for (int i = 0; i < TOTAL_PAIRS; i++) {
                cardArray[i] = cardImages[i];
                cardArray[i + TOTAL_PAIRS] = cardImages[i];
            }
        }

        private void shuffleAndResetGame() {
            // 1. Reset game state first
            resetGameState();

            // 2. Shuffle the card array with no adjacent pairs
            shuffleWithNoAdjacentPairs();

            // 3. Create card views if needed
            if (cards == null) {
                createCardViews();
            } else {
                // Reset existing cards to face down
                resetCardsToFaceDown();
            }

            // 4. Add shuffle animation
            animateShuffle();
        }

        private void shuffleWithNoAdjacentPairs() {
            List<Integer> cardList = new ArrayList<>();
            for (int i = 0; i < TOTAL_PAIRS; i++) {
                cardList.add(i);
                cardList.add(i);
            }

            Random random = new Random();
            boolean validShuffle;

            do {
                validShuffle = true;
                Collections.shuffle(cardList);

                // Check for adjacent pairs
                for (int i = 1; i < cardList.size(); i++) {
                    if (cardList.get(i).equals(cardList.get(i - 1))) {
                        validShuffle = false;
                        break;
                    }
                }
            } while (!validShuffle);

            // Convert to array
            for (int i = 0; i < cardArray.length; i++) {
                cardArray[i] = cardImages[cardList.get(i)];
            }
        }

        private void resetCardsToFaceDown() {
            if (cards != null) {
                for (Button card : cards) {
                    if (card != null) {
                        card.setBackgroundResource(R.drawable.card_back);
                    }
                }
            }
        }

        private void resetGameState() {
            firstCard = -1;
            secondCard = -1;
            matchedPairs = 0;
            isBusy = false;
            tvWinMessage.setVisibility(View.GONE);
        }

        private void createCardViews() {
            gridLayout.removeAllViews();
            cards = new Button[12];

            for (int i = 0; i < 12; i++) {
                cards[i] = new Button(this);
                cards[i].setBackgroundResource(cardBack[0]);
                cards[i].setTag(i);

                GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                params.width = getResources().getDimensionPixelSize(R.dimen.card_width);
                params.height = getResources().getDimensionPixelSize(R.dimen.card_height);
                params.setMargins(8, 8, 8, 8);
                cards[i].setLayoutParams(params);

                cards[i].setOnClickListener(this::onCardClick);
                gridLayout.addView(cards[i]);
            }
        }

        private void animateShuffle() {
            // Show all cards briefly
            for (int i = 0; i < cards.length; i++) {
                cards[i].setBackgroundResource(cardArray[i]);
            }

            // Then flip them back after a delay
            new Handler().postDelayed(() -> {
                for (Button card : cards) {
                    card.setBackgroundResource(R.drawable.card_back);
                    card.animate()
                            .rotationYBy(360)
                            .setDuration(300)
                            .start();
                }
            }, 500);
        }

        private void onCardClick(View view) {
            if (isBusy) return;

            int clickedCard = (int) view.getTag();

            // Ignore already matched cards
            if (cards[clickedCard].getBackground().getConstantState() ==
                    getResources().getDrawable(cardArray[clickedCard]).getConstantState()) {
                return;
            }

            // First card selection
            if (firstCard == -1) {
                firstCard = clickedCard;
                cards[firstCard].setBackgroundResource(cardArray[firstCard]);
                return;
            }

            // Second card selection
            if (clickedCard != firstCard && secondCard == -1) {
                secondCard = clickedCard;
                cards[secondCard].setBackgroundResource(cardArray[secondCard]);

                // Check for match
                if (cardArray[firstCard] == cardArray[secondCard]) {
                    matchedPairs++;
                    firstCard = -1;
                    secondCard = -1;

                    if (matchedPairs == TOTAL_PAIRS) {
                        showWinAndReshuffle();
                    }
                } else {
                    isBusy = true;
                    new Handler().postDelayed(() -> {
                        cards[firstCard].setBackgroundResource(cardBack[0]);
                        cards[secondCard].setBackgroundResource(cardBack[0]);
                        firstCard = -1;
                        secondCard = -1;
                        isBusy = false;
                    }, 1000);
                }
            }
        }

        private void showWinAndReshuffle() {
            tvWinMessage.setVisibility(View.VISIBLE);
            new Handler().postDelayed(() -> {
                tvWinMessage.setVisibility(View.GONE);
                shuffleAndResetGame();
            }, 1500);
            if (gameData.getInt(userData.getString("Current User", "Guest")+"Stage", 0) < 10) {
                gameDataEditor = gameData.edit();

                gameDataEditor.putInt(userData.getString("Current User", "Guest") + "Stage", gameData.getInt(userData.getString("Current User", "Guest") + "Stage", 0) + 1);
                gameDataEditor.apply();
            }
        }
    }
